"""The project's real entry: defence + HYDRA as one system.   ai-cyber [--defence-*] <hydra args>

  --defence-rebaseline   accept the current HYDRA code as the new trusted baseline (after you changed it on purpose)
  --defence-restore      restore drifted HYDRA files from git HEAD (verified against the signed baseline)
Everything else is passed to HYDRA unchanged. Key, baseline and audit logs are managed automatically in <repo>/.ai_cyber/."""
from __future__ import annotations

import datetime
import io
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
from typing import Callable, Optional, Sequence

from .crypto_integrity import Integrity
from .integrity_gate import write_baseline
from .keystore import DefaultKeyProvider
from . import launcher

HYDRA_REL = os.path.join("src", "ai_cyber_os")


def repo_root() -> str:
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def git_clean_source(root: str, rel: str = HYDRA_REL) -> str:
    """Pristine copy of the HYDRA dir from git HEAD, in a temp dir (caller deletes it)."""
    data = subprocess.run(["git", "-C", root, "archive", "HEAD", rel.replace(os.sep, "/")],
                          check=True, capture_output=True).stdout
    tmp = tempfile.mkdtemp(prefix="aicyber_clean_")
    with tarfile.open(fileobj=io.BytesIO(data)) as t:
        t.extractall(tmp, filter="data")
    return os.path.join(tmp, rel)


def main(argv: Optional[Sequence[str]] = None, *, root: Optional[str] = None,
         hydra_main: Optional[Callable[[Sequence[str]], int]] = None, out=print) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    rebaseline = "--defence-rebaseline" in argv
    restore = "--defence-restore" in argv
    args = [a for a in argv if a not in ("--defence-rebaseline", "--defence-restore")]

    root = root or repo_root()
    state = os.path.join(root, ".ai_cyber")
    provider = DefaultKeyProvider(state)
    target = os.path.join(root, HYDRA_REL)
    baseline = os.path.join(state, "hydra_baseline.json")

    if rebaseline or not os.path.exists(baseline):
        n = write_baseline(target, baseline, Integrity(provider))
        out(f"defence: baseline {'updated' if rebaseline else 'initialised (first start)'} - {n} HYDRA files")

    clean = None
    if restore:
        try:
            clean = git_clean_source(root)
        except Exception as e:
            out(f"defence: cannot read clean copy from git ({type(e).__name__}); restore unavailable")
    audit_dir = os.path.join(state, "audit"); os.makedirs(audit_dir, exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    try:
        rc = launcher.run(args, hydra_main=hydra_main, key_provider=provider, out=out, hydra_dir=target,
                          baseline_path=baseline, clean_source=clean,
                          audit_file=os.path.join(audit_dir, f"{stamp}.jsonl"))
    finally:
        if clean:
            shutil.rmtree(os.path.dirname(os.path.dirname(clean)), ignore_errors=True)
    if rc == 4:
        out("defence: HYDRA code differs from the trusted baseline. If you changed it on purpose: "
            "--defence-rebaseline. To undo unwanted changes: --defence-restore.")
    return rc

